package org.iesbelen.streams.dao;

import org.iesbelen.streams.entity.Departamento;

import java.util.List;

public interface DepartamentoDAO {
    List<Departamento> findAll();
//    Departamento findOne(Long id);
//    boolean create(Departamento departamento);
//    boolean update(Departamento departamento);
//    boolean delete(Long id);

}
