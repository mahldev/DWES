package org.iesbelen.streams.service;

import org.iesbelen.streams.entity.Empleado;

public interface EmpleadoService {

    boolean create(Empleado empleado);

    // logica de negocio

    // realizar calculo
}

