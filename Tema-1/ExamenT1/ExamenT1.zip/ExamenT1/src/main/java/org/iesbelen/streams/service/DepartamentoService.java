package org.iesbelen.streams.service;

import org.iesbelen.streams.entity.Departamento;

public interface DepartamentoService {

    boolean create(Departamento departamento);

    // logica de negocio

    // realizar calculo

}
